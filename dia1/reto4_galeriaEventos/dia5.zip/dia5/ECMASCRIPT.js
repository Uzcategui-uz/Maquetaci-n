// function mensaje(cadena = 'no hay mensaje') {
//     console.log(cadena)
// }
let mensaje = (cadena = 'no hay mensaje') => {
    console.log (cadena);
}
let cadena = "colgante, dorado"
// let mensaje = (cadena ="no hay parametro")
// console.log (cadena)


mensaje()
