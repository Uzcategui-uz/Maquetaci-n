function multypli(x, y) {
    return x * y;
}
let multypli2 = (x, y) => {

    let result = x * y;

    return result;

}

let mult = multypli2(9, 6)

console.log(mult)
