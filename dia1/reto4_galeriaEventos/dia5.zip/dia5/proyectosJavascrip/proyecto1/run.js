let myLib = require("./index");

myLib.suma(9,6)
myLib.resta (9, 6)
myLib.producto(9,6)
myLib.divicion(9,6)
/*
let vector = require("./libreriaVector");
let funsiones = require("./libreriaFuncion");
console.log(myLib.suma(5, 8));
console.log(myLib.resta(5, 8));
console.log(myLib.producto(5, 8));
console.log(myLib.divicion(5, 8));

let v1 = vector.crearVector(5,100);
let v2 = vector.crearVector(5,100);
console.log(v1);
console.log(v2);
console.log(vector.sumaVector(v1, v2));
console.log(vector.productoNumeroVector(10,v1));
console.log(vector.restaVector(v1,v2));
console.log(vector.productoVector(v1,v2));

console.log(funsiones.sumaVector1(v1,v2));
console.log(funsiones.sumaVector2(v1,v2));
console.log(funsiones.filtarPares(v1));
console.log(funsiones.sumatorio(v1));
*/






