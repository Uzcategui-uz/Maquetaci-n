function suma(op1, op2) {
    return op1+op2;
}

function resta(op1, op2) {
    return op1-op2;
}

function producto(op1, op2) {
    return op1*op2;
}

function divicion(op1, op2) {
    return op1/op2;
}


module.exports={suma, resta, producto,divicion};