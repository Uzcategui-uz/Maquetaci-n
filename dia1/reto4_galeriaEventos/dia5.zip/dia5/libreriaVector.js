function crearVector(n, m) {
    let lista = Array();
    for (let i = 0; i < n; i++) {
        lista.push(getRandomInt(0, m));


    }
    return lista;
}
//ramdom javascrip//
function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}


//5,6,3+2,4,8=7,10,11//
function sumaVector(v1, v2) {
    let v3 = Array();
    if (v1.length == v2.length) {
        for (let i = 0; i < v1.length; i++) {
            v3.push(v1[i] + v2[i]);

        }
        return v3;
    }

}
function productoNumeroVector(n, v) {
    let v1 = Array();
    for (let i = 0; i < v.length; i++) {
        v1.push(v[i] * n);

    }
    return v1;

}
function restaVector(v1, v2) {
    let v3 = Array();
    if (v1.length == v2.length) {
        for (let i = 0; i < v1.length; i++) {
            v3.push(v1[i] - v2[i]);

        }
        return v3;
    }

}
function productoVector(v1, v2) {
    let v3 = Array();
    if (v1.length == v2.length) {
        for (let i = 0; i < v1.length; i++) {
            v3.push(v1[i] * v2[i]);

        }
        return v3;
    }
}
        module.exports={crearVector, sumaVector, productoNumeroVector, restaVector, productoVector };
        










