# Pasos para subir un proyecto a git

- crear un repositorio con git init 
- Git status para conocer el estado de los archivos
- Subir los archivos al stage con git add nombreDelArchivo
- Realizar un commir para confirmar los archivos que se subirán al repositorio remoto
- git push para subir los cambios al repositorio

#Reto 4 punto 3

todos los archivos introducidos en .gitignore no han sido subidos al repositorio remoto, aunque el el .gitignore si ha subido a este repositorio 