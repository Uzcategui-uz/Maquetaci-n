# repositorio-reto1


- Se ha formado un conflicto por las funciones modificadas pero se han solucionado dejando como resultado las funciones modificas en la rama 2